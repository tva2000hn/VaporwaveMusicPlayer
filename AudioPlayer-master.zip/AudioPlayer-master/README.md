# AudioPlayer

A simple Android Audio player App for playing audio files in a background service. 

The service can be used to play both local media files and streaming media from remote APIs.

|![Screenshot](https://github.com/valdio/AudioPlayer/blob/master/Screenshots/Screenshot_2016-08-12-19-31-48.png)|![Screenshot](https://github.com/valdio/AudioPlayer/blob/master/Screenshots/Screenshot_2016-08-12-19-32-09.png)|
| ------------- | ------------- |
|![Screenshot](https://github.com/valdio/AudioPlayer/blob/master/Screenshots/Screenshot_2016-07-30-13-28-42.png)|![Screenshot](https://github.com/valdio/AudioPlayer/blob/master/Screenshots/Screenshot_2016-08-12-19-32-28.png)|




