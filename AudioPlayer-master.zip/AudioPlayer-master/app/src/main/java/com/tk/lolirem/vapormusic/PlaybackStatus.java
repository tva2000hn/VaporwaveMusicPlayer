package com.tk.lolirem.vapormusic;


public enum PlaybackStatus {
    PLAYING,
    PAUSED
}
