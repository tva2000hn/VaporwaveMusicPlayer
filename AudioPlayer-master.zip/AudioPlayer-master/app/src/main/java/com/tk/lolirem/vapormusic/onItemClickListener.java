package com.tk.lolirem.vapormusic;

import android.view.View;


public interface onItemClickListener {

    public void onClick(View view, int index);
}
